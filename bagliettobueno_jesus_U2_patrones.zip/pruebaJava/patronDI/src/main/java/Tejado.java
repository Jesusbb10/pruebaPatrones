public class Tejado {
    Tejado tejado;
    private int area;


    public Tejado(Tejado tejado, int area) {
        this.tejado = tejado;
        this.area = area;
    }

    public Tejado getTejado() {
        return tejado;
    }

    public void setTejado(Tejado tejado) {
        this.tejado = tejado;
    }


public void darSoporte() {

}

}
