public class Area {

    private int area;


    public Area(int area) {
        this.area  = area;
    }

    public int getArea() {
        return area;
    }

    public void setArea(int area) {
        this.area = area;
    }
}
