package org.example;

public class Main {
    public static void main(String[] args) {
    Casa casa1 = new Casa();
    }
}