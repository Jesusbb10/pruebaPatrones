public class TejadoTejas extends Tejado{

    TejadoTejas tejadoTejas;
    private int area;

    public TejadoTejas(TejadoTejas tejadoTejas, int area) {
        this.tejadoTejas = tejadoTejas;
        this.area=area;
    }
}
