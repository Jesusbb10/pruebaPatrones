public class Casa {

    public  Casa(Casa casa) {

    }
}
